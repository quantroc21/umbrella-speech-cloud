import os
import requests
import time
from concurrent.futures import ThreadPoolExecutor

def download_chunk(url, start, end, filename, chunk_id, token, max_retries=10):
    headers = {"Authorization": f"Bearer {token}", "Range": f"bytes={start}-{end}"}
    part_file = f"{filename}.part{chunk_id}"
    
    for attempt in range(max_retries):
        try:
            current_size = os.path.getsize(part_file) if os.path.exists(part_file) else 0
            if current_size >= (end - start + 1):
                return True
                
            if current_size > 0:
                headers["Range"] = f"bytes={start + current_size}-{end}"
            
            r = requests.get(url, headers=headers, stream=True, timeout=30)
            r.raise_for_status()
            
            with open(part_file, "ab" if current_size > 0 else "wb") as f:
                last_print = 0
                for chunk in r.iter_content(chunk_size=1024*1024):
                    if chunk:
                        f.write(chunk)
                        current_size += len(chunk)
                        if (current_size - last_print) >= (1024*1024 * 10): # Print every 10MB
                             print(f"File {os.path.basename(filename)} Chunk {chunk_id}: {current_size/(1024*1024):.1f} MB", flush=True)
                             last_print = current_size
            return True
        except Exception as e:
            print(f"File {os.path.basename(filename)} Chunk {chunk_id} attempt {attempt+1} failed: {e}", flush=True)
            time.sleep(2)
    return False

def fast_download(url, filename, token, num_chunks=8):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.head(url, headers=headers, allow_redirects=True)
    total_size = int(r.headers.get('content-length', 0))
    
    if os.path.exists(filename) and os.path.getsize(filename) == total_size:
        print(f"{filename} already done.", flush=True)
        return

    print(f"Fast downloading {filename} ({total_size / (1024*1024):.1f} MB) with {num_chunks} threads...", flush=True)
    chunk_size = total_size // num_chunks
    
    while True:
        futures = []
        with ThreadPoolExecutor(max_workers=num_chunks) as executor:
            for i in range(num_chunks):
                start = i * chunk_size
                end = (i + 1) * chunk_size - 1 if i < num_chunks - 1 else total_size - 1
                futures.append(executor.submit(download_chunk, url, start, end, filename, i, token))
        
        if all(f.result() for f in futures):
            break
        print(f"Some chunks failed for {filename}, retrying loop...", flush=True)
        time.sleep(5)

    print(f"Merging {filename}...", flush=True)
    with open(filename, "wb") as final_file:
        for i in range(num_chunks):
            with open(f"{filename}.part{i}", "rb") as part_file:
                final_file.write(part_file.read())
            os.remove(f"{filename}.part{i}")
    print(f"Successfully finished {filename}", flush=True)

if __name__ == "__main__":
    token = "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"
    repo = "fishaudio/openaudio-s1-mini"
    base_url = f"https://huggingface.co/{repo}/resolve/main/"
    os.makedirs("checkpoints/openaudio-s1-mini", exist_ok=True)
    
    files = ["model.pth", "codec.pth"]
    for f in files:
        fast_download(base_url + f, f"checkpoints/openaudio-s1-mini/{f}", token)
