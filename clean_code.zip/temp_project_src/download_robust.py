import requests
import os
import sys

def download_file(url, filename, token):
    headers = {"Authorization": f"Bearer {token}"}
    try:
        r = requests.get(url, headers=headers, stream=True, timeout=600)
        r.raise_for_status()
        total_size = int(r.headers.get('content-length', 0))
        print(f"Downloading {filename} ({total_size} bytes)...")
        with open(filename, 'wb') as f:
            done = 0
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk:
                    f.write(chunk)
                    done += len(chunk)
                    if done % (1024*1024 * 10) == 0: # Print every 10MB
                        print(f"Downloaded {done / (1024*1024):.1f} MB / {total_size / (1024*1024):.1f} MB", flush=True)
        print(f"Finished {filename}")
    except Exception as e:
        print(f"Error downloading {filename}: {e}")

if __name__ == "__main__":
    token = "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"
    base_url = "https://huggingface.co/fishaudio/openaudio-s1-mini/resolve/main/"
    os.makedirs("checkpoints/openaudio-s1-mini", exist_ok=True)
    
    # Download model.pth and codec.pth
    download_file(base_url + "model.pth", "checkpoints/openaudio-s1-mini/model.pth", token)
    download_file(base_url + "codec.pth", "checkpoints/openaudio-s1-mini/codec.pth", token)
