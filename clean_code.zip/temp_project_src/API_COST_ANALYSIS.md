# Fish Speech Project - API Cost Analysis

## Executive Summary

**✅ GOOD NEWS: This project does NOT require any paid APIs to run locally!**

The Fish Speech project is a **completely self-hosted, open-source Text-to-Speech (TTS) system** that runs entirely on your local machine without requiring any external paid API services.

---

## Detailed Analysis

### 1. **Core Functionality - 100% Local**

The project is a complete TTS system that:
- Runs locally on your GPU/CPU
- Uses open-source models (OpenAudio S1, OpenAudio S1-mini)
- Processes speech synthesis entirely on your machine
- Provides both API server and WebUI interfaces

**API Cost: $0** ✅

---

### 2. **Model Downloads - Free from HuggingFace**

#### Found in: `tools/download_models.py`

```python
from huggingface_hub import hf_hub_download
```

**Purpose**: Downloads pre-trained models from HuggingFace repositories
- Repository: `fishaudio/openaudio-s1-mini`
- Repository: `fishaudio/fish-speech-1`
- Repository: `SpicyqSama007/fish-speech-packed`

**Cost**: FREE ✅
- HuggingFace model hosting is free
- No API keys required
- Downloads happen once, models stored locally

---

### 3. **Optional Training Monitoring - WandB (Optional)**

#### Found in: `fish_speech/utils/utils.py`

```python
import wandb
if wandb.run:
    wandb.finish()
```

**Purpose**: Optional experiment tracking for model training
- Used only if you're training/fine-tuning models
- **NOT required for inference/usage**
- Only activates if wandb is installed and configured

**Cost for Basic Use**: $0 ✅
- Free tier available for personal projects
- Only needed if YOU decide to train models
- Not required to run the TTS service

**Recommendation**: You can completely ignore this - it's only for developers training models.

---

### 4. **API Server Authentication - Local Only**

#### Found in: `tools/api_server.py`

```python
def api_auth(endpoint):
    async def verify(token: Annotated[str, Depends(bearer_auth)]):
        if token != self.args.api_key:
            raise HTTPException(401, None, "Invalid token")
```

**Purpose**: Optional API key protection for YOUR local API server
- This is YOUR API key that YOU set (not a third-party service)
- Used to protect your local server from unauthorized access
- Completely optional and local

**Cost**: $0 ✅

---

### 5. **Dependencies Analysis**

Analyzed `pyproject.toml` for all dependencies:

#### Core ML Libraries (All Open Source, No API Costs):
- `torch` - PyTorch (local computation)
- `transformers` - HuggingFace (local model loading)
- `librosa` - Audio processing (local)
- `descript-audio-codec` - Audio codec (local)

#### Server/API Libraries (Self-Hosted):
- `uvicorn` - ASGI server (runs locally)
- `gradio` - WebUI framework (runs locally)
- `kui` - API framework (runs locally)

#### Optional Services:
- `wandb` - Experiment tracking (optional, free tier available)
- `tensorboard` - Training visualization (100% local, free)

**All dependencies: Either fully local or have generous free tiers** ✅

---

## What This Project Actually Does

1. **Downloads** open-source TTS models (one-time, free)
2. **Runs** a local API server on your machine
3. **Processes** text-to-speech requests using your GPU/CPU
4. **Serves** results through a WebUI or API endpoints

**Everything happens on YOUR machine.**

---

## Potential Costs (All Optional)

### Hardware/Compute (If you don't have a GPU):
- ❌ Cloud GPU rental (e.g., AWS, Google Cloud) - **Only if you choose cloud hosting**
- ✅ Local GPU/CPU - **Free if you run on your own machine**

### Training (Only if you fine-tune models):
- ❌ WandB Teams plan - **Only if you want team features**
- ✅ WandB free tier - **Sufficient for personal projects**
- ✅ TensorBoard - **Completely free, runs locally**

---

## Verified: No External API Calls Found

Searched the entire codebase for:
- ❌ OpenAI API calls
- ❌ Google Cloud API calls
- ❌ AWS API calls
- ❌ Azure API calls
- ❌ Payment processing (Stripe, etc.)
- ❌ External TTS services
- ❌ Any paid third-party APIs

**Result: NONE FOUND** ✅

---

## Recommendation for Zero-Cost Usage

### To run this project with $0 API costs:

1. **Run locally on your machine** (Windows/Linux)
2. **Use your own GPU/CPU** for inference
3. **Download free models** from HuggingFace
4. **Skip WandB** (don't install or configure it)
5. **Use the free WebUI** (Gradio-based)

### Setup Commands (from API_FLAGS.txt):
```bash
python tools/api_server.py --api --listen 0.0.0.0:8080 \
  --llama-checkpoint-path "checkpoints/openaudio-s1-mini" \
  --decoder-checkpoint-path "checkpoints/openaudio-s1-mini/codec.pth" \
  --decoder-config-name modded_dac_vq
```

This runs everything locally - no external API calls, no costs.

---

## Final Verdict

### ✅ **You can use this project with ZERO API costs!**

This is a **self-contained, open-source TTS system** that:
- Runs entirely on your hardware
- Uses free open-source models
- Requires no paid API subscriptions
- Has no hidden costs

The only potential costs would be:
1. Electricity for running your computer ⚡
2. Cloud hosting IF you choose to deploy remotely (optional)
3. Premium WandB IF you're training models and want team features (optional)

**For basic TTS usage: $0 in API costs** 🎉

---

## Notes

- The mention of "OpenAI gpt-4o-transcribe" in README is only for benchmarking/evaluation (not required for usage)
- HuggingFace API usage in code is for downloading models (free, no API key needed)
- All inference and processing happens locally

**Date of Analysis**: 2025-12-28
**Project**: Fish Speech (OpenAudio S1)
**License**: Apache-2.0 (Code), CC-BY-NC-SA-4.0 (Models)
