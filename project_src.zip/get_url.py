import json
try:
    with open('ngrok_status_final.json', 'r') as f:
        data = json.load(f)
    print(data['tunnels'][0]['public_url'])
except Exception as e:
    print(f"Error: {e}")
