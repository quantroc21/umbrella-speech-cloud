import os
import requests
import time

def download_file_with_resume(url, filename, token):
    headers = {"Authorization": f"Bearer {token}"}
    
    # Check if file exists and get its size
    if os.path.exists(filename):
        resume_byte = os.path.getsize(filename)
    else:
        resume_byte = 0
    
    # Get total size first
    try:
        r = requests.head(url, headers=headers, allow_redirects=True, timeout=30)
        total_size = int(r.headers.get('content-length', 0))
    except Exception as e:
        print(f"Error getting metadata for {filename}: {e}")
        return

    if resume_byte >= total_size and total_size > 0:
        print(f"{filename} is already downloaded.")
        return

    print(f"Downloading {filename} ({total_size} bytes, resuming from {resume_byte})...")
    
    if resume_byte > 0:
        headers['Range'] = f"bytes={resume_byte}-"

    try:
        r = requests.get(url, headers=headers, stream=True, timeout=60)
        r.raise_for_status()
        
        mode = 'ab' if resume_byte > 0 else 'wb'
        with open(filename, mode) as f:
            done = resume_byte
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk:
                    f.write(chunk)
                    done += len(chunk)
                    if done % (1024*1024 * 10) == 0: # Print every 10MB
                        print(f"Downloaded {done / (1024*1024):.1f} MB / {total_size / (1024*1024):.1f} MB", flush=True)
        print(f"Finished {filename}")
    except Exception as e:
        print(f"Error downloading {filename}: {e}")
        # Wait and retry once
        time.sleep(5)
        print("Retrying...")
        download_file_with_resume(url, filename, token)

if __name__ == "__main__":
    token = "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"
    repo = "fishaudio/openaudio-s1-mini"
    base_url = f"https://huggingface.co/{repo}/resolve/main/"
    os.makedirs("checkpoints/openaudio-s1-mini", exist_ok=True)
    
    files = ["model.pth", "codec.pth", "tokenizer.tiktoken", "config.json", "special_tokens.json"]
    for f in files:
        download_file_with_resume(base_url + f, f"checkpoints/openaudio-s1-mini/{f}", token)
