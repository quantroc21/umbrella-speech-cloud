import torch
import time
from fish_speech.models.text2semantic.inference import init_model
from fish_speech.utils.schema import ServeTTSRequest
from fish_speech.inference_engine import TTSInferenceEngine
from fish_speech.models.dac.inference import load_model as load_decoder_model
import queue

def test_speed():
    device = "cpu"
    precision = torch.bfloat16
    checkpoint_path = "checkpoints/openaudio-s1-mini"
    
    torch.set_num_threads(1)
    torch.set_flush_denormal(True)
    
    print("Loading Llama...")
    model, decode_one_token = init_model(checkpoint_path, device, precision, compile=False)
    
    # Setup cache
    with torch.device(device):
        model.setup_caches(max_batch_size=1, max_seq_len=2048, dtype=precision)
    
    print("Loading Decoder...")
    decoder = load_decoder_model("modded_dac_vq", "checkpoints/openaudio-s1-mini/codec.pth", device)
    
    llama_queue = queue.Queue()
    # Dummy worker for llama_queue
    def worker():
        pass # Not needed for direct call
    
    engine = TTSInferenceEngine(llama_queue, decoder, precision, False)
    # We bypass the queue for timing
    
    from fish_speech.models.text2semantic.inference import generate_long
    
    text = "Hi"
    print(f"Testing generation for: {text}")
    
    t0 = time.time()
    # Direct call to generate_long to see it/s
    generator = generate_long(
        model=model,
        device=device,
        decode_one_token=decode_one_token,
        text=text,
        max_new_tokens=100
    )
    for res in generator:
        pass
    t1 = time.time()
    print(f"Total time: {t1-t0:.2f}s")

if __name__ == "__main__":
    test_speed()
